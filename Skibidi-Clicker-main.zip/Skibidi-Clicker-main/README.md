Please don't copy all of my code and call it your own. You can use it for help or for inspiration just don't take the entire project for yourself.
